import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, QHBoxLayout
from PyQt5.QtCore import Qt

class BuddySystem:
    def __init__(self, total_memory):
        self.total_memory = total_memory
        self.free_blocks = {total_memory: [0]}  # Dictionary to track free blocks by size

    def _next_power_of_two(self, size):
        return 1 << (size - 1).bit_length()

    def allocate(self, size):
        block_size = self._next_power_of_two(size)
        for free_size in sorted(self.free_blocks.keys()):
            if free_size >= block_size and self.free_blocks[free_size]:
                address = self.free_blocks[free_size].pop(0)
                while free_size > block_size:
                    free_size //= 2
                    buddy_address = address + free_size
                    self.free_blocks.setdefault(free_size, []).append(buddy_address)
                return address
        return None

    def deallocate(self, address, size):
        block_size = self._next_power_of_two(size)
        self.free_blocks.setdefault(block_size, []).append(address)
        self._merge_blocks(block_size)

    def _merge_blocks(self, block_size):
        merged = True
        while merged:
            merged = False
            if block_size not in self.free_blocks:
                break
            free_list = sorted(self.free_blocks[block_size])
            new_free_list = []
            skip_next = False
            for i in range(len(free_list) - 1):
                if skip_next:
                    skip_next = False
                    continue
                if free_list[i] ^ block_size == free_list[i + 1]:
                    merged_block = min(free_list[i], free_list[i + 1])
                    self.free_blocks.setdefault(block_size * 2, []).append(merged_block)
                    skip_next = True
                    merged = True
                else:
                    new_free_list.append(free_list[i])
            if not skip_next:
                new_free_list.append(free_list[-1])
            self.free_blocks[block_size] = new_free_list
            block_size *= 2

    def get_free_blocks(self):
        return "\n".join(["Block size {}: {}".format(size, blocks) for size, blocks in sorted(self.free_blocks.items()) if blocks])


class BuddySystemUI(QWidget):
    def __init__(self):
        super().__init__()
        self.buddy_system = BuddySystem(1024)  # Initialize BuddySystem with 1024 units
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('Buddy System Memory Allocation')
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()

        # Label to show the free blocks
        self.free_blocks_label = QLabel('Free Blocks:', self)
        layout.addWidget(self.free_blocks_label)

        # Text area to display free blocks
        self.free_blocks_text = QLabel(self.buddy_system.get_free_blocks(), self)
        self.free_blocks_text.setAlignment(Qt.AlignTop)
        layout.addWidget(self.free_blocks_text)

        # User input for memory allocation and deallocation
        self.memory_input_label = QLabel('Enter memory size to allocate/deallocate:', self)
        layout.addWidget(self.memory_input_label)

        self.memory_input = QLineEdit(self)
        layout.addWidget(self.memory_input)

        # Buttons
        allocate_button = QPushButton('Allocate Memory', self)
        allocate_button.clicked.connect(self.allocate_memory)
        layout.addWidget(allocate_button)

        deallocate_button = QPushButton('Deallocate Memory', self)
        deallocate_button.clicked.connect(self.deallocate_memory)
        layout.addWidget(deallocate_button)

        # Set the layout
        self.setLayout(layout)

    def update_free_blocks(self):
        self.free_blocks_text.setText(self.buddy_system.get_free_blocks())

    def allocate_memory(self):
        size = self.memory_input.text()
        if not size.isdigit():
            return
        size = int(size)
        address = self.buddy_system.allocate(size)
        if address is None:
            self.free_blocks_label.setText("Allocation failed: Not enough memory for size {}".format(size))
        else:
            self.free_blocks_label.setText("Allocated {} units at address: {}".format(size, address))
        self.update_free_blocks()

    def deallocate_memory(self):
        size = self.memory_input.text()
        if not size.isdigit():
            return
        size = int(size)
        self.buddy_system.deallocate(0, size)  # Deallocate from address 0 (for simplicity)
        self.free_blocks_label.setText("Deallocated {} units from address 0".format(size))
        self.update_free_blocks()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = BuddySystemUI()
    window.show()
    sys.exit(app.exec_())

